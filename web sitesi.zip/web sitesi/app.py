from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route('/')
def ana_sayfa():
    return render_template('index.html')

@app.route('/kayit', methods=['POST'])
def kayit():
    email = request.form['email']
    kullanici_adi = request.form['kullanici_adi']
    sifre = request.form['sifre']

    with open('/root/Desktop/kullanicilar.txt', 'a') as dosya:
        dosya.write(f"{email},{kullanici_adi},{sifre}\n")

    return redirect('/giris')

@app.route('/giris')
def giris_sayfasi():
    return render_template('giris.html')

if __name__ == '__main__':
    app.run(debug=True)
